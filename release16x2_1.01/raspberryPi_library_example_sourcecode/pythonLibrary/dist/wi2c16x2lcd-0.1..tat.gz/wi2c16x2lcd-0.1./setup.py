from setuptools import setup

setup(
    name='wi2c16x2lcd',
    version='0.1 ' ,
    packages=['wi2c16x2lcd'],
    license='NONE',
    ) 
