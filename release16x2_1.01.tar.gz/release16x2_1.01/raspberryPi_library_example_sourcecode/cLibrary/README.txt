//TO INSTALL wi2c16x2lcd LIBRARY :
sudo cp libwi2c16x2lcd.a  /usr/lib/
sudo cp wi2c16x2lcd.h  /usr/include/
